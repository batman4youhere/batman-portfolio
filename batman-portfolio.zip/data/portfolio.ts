export const portfolio = {
  name: "Batman",

  title: "Freelance Digital Marketer | Video Editor | Content Creator",

  tagline:
    "Helping Brands Grow Through Digital Marketing & Cinematic Video Editing.",

  about:
    "I'm a freelance Digital Marketer and Video Editor passionate about helping businesses build a strong online presence through cinematic content and performance-driven marketing.",

  email: "batman.4you@icloud.com",

  skills: [
    "Adobe Premiere Pro",
    "After Effects",
    "CapCut",
    "Photoshop",
    "Canva",
    "Digital Marketing",
    "Social Media Marketing",
    "Meta Ads",
    "Google Ads",
    "SEO",
    "Content Strategy",
    "Branding",
    "Copywriting",
    "Analytics",
    "Performance Marketing",
  ],
};
