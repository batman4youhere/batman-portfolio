export const COLORS = {
  background: "#0B0B0B",
  card: "#141414",
  border: "#242424",

  primary: "#FFFFFF",

  secondary: "#A0A0A0",

  accent: "#B68D40",
};
